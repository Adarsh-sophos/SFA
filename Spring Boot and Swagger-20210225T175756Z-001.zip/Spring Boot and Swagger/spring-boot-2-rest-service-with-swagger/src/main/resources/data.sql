insert into student
values(10001,'David', 'E1234567');

insert into student
values(10002,'Mai', 'A1234568');