# RestTemplate

Tutorials related to this project:

1. [Spring RestTemplate](https://howtodoinjava.com/spring-boot2/resttemplate/spring-restful-client-resttemplate-example/)
2. [Spring Boot - @RestClientTest](https://howtodoinjava.com/spring-boot2/testing/restclienttest-test-services/)
3. [Spring RestTemplate with HttpClient configuration](https://howtodoinjava.com/spring-boot2/resttemplate/resttemplate-httpclient-java-config/)