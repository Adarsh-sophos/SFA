package com.example.service;

public interface UserService {
	
	public String testUserService();

}
