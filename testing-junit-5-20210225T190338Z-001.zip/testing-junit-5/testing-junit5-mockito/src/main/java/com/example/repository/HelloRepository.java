package com.example.repository;

public interface HelloRepository {
    String get();
}
