package com.example.services;

public interface HelloService {

    String get();

}
